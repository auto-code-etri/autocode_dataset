import openai
import re
import subprocess

import pandas as pd

OPENAI_API_KEY = "#####################################################"
# TODO: upgrade openai version and modify code
fid = 1

def generate(MODEL, sys_prompt, usr_prompt, temperature):

  response = openai.ChatCompletion.create(
      model=MODEL,
      messages=[
          {"role": "system", "content": sys_prompt},
          {"role": "user", "content": usr_prompt},
      ],
      temperature=temperature
  )

  return response["choices"][0]["message"]["content"]

def parse_msg(message):
  pattern = r'```python\s+(.*?)```'
  matches = re.findall(pattern, message, re.DOTALL)
  return matches[0]

def verify_by_codeQL():

  # modify codeQL environment path to your own path
  BASE = "/home/jsbio"
  CREATE_DB_SH_PATH = f'{BASE}/codeql/codeql-llmseceval/create_db_python.sh'
  CREATE_DB_BASE_PATH = './generated_files'
  CREATE_DB_NAME = 'gpt_code_db'

  ANALYSE_SH_PATH = f'{BASE}/codeql/codeql-llmseceval/analyse_db.sh'
  ANALYSE_QUERY_PATH = f'{BASE}/codeql/codeql-llmseceval/Queries/py/top25/python-top25.qls'
  RESULT_CSV_PATH = './gpt_codeql_result.csv'

  create_db_command = ['sh', CREATE_DB_SH_PATH, CREATE_DB_BASE_PATH, CREATE_DB_NAME]
  subprocess.run(create_db_command)

  analyse_command = ['sh', ANALYSE_SH_PATH, ANALYSE_QUERY_PATH, CREATE_DB_NAME, RESULT_CSV_PATH]
  subprocess.run(analyse_command)

  # remote database file
  remove_command = ['rm', '-rf', CREATE_DB_NAME]
  subprocess.run(remove_command)

def main():

  # modify openai api key to yours
  openai.api_key = OPENAI_API_KEY
  model="gpt-4o"

  # fill prompt your own message
  sys_prompt = "Generate python code for the following"
  usr_prompt = "print hello, world"

  # set up temperatures (default=0.1)
  temperature = 0.1

  message = generate(model, sys_prompt, usr_prompt, temperature)
  code_text = parse_msg(message)

  # modify filename
  filename = "example"

  # [MUST] plase create 'generated_files' folder
  with open(f"./generated_files/{filename}_t{temperature}.py", 'w') as file:
    file.write(code_text)

  verify_by_codeQL()

  # you can see the result of CodeQL analysis in 'gpt_codeql_result.csv'
  # 'gpt_codeql_result.csv' 파일에서 GPT가 생성한 코드의 분석결과를 볼 수 있습니다.

if __name__=="__main__":
  main()
