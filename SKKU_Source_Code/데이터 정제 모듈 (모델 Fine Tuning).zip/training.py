from transformers import AutoTokenizer, AutoModelForCausalLM, Trainer, TrainingArguments
from datasets import Dataset

import torch
import pandas as pd


# load model and tokenizer
model_name = "Salesforce/codegen-350M-mono"
device = 'cuda' if torch.cuda.is_available() else 'cpu'

tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name).to(device)

# load dataset for fine-tuning model
database_path = "model_dataset.csv"
df = pd.read_csv(database_path)
raw_dataset = df.to_dict(orient="records")

# edit prompts to generate 'python' code
for item in raw_dataset:
    if "prompt" in item:
        item["prompt"] = item["prompt"].replace("<language>", "python")
        item['mode_code'] = '\n' + item['mode_code']

# print example dataset to check 
print(raw_dataset[0])

# raw dataset was converted to Dataset
dataset = Dataset.from_list(raw_dataset)
print(dataset)

if tokenizer.pad_token is None:
  tokenizer.pad_token = tokenizer.eos_token

# dataset tokenizing
def tokenize_function(examples):
    input_target = tokenizer(examples["prompt"], padding="max_length", truncation=True, max_length=256, add_special_tokens=False)
    input_code = tokenizer(examples["mode_code"], padding="max_length", truncation=True, max_length=256, add_special_tokens=False)

    input_target['labels'] = input_code['input_ids']
    return input_target

tokenized_dataset = dataset.map(tokenize_function, batched=True)

print(tokenized_dataset)

# setting training argument
training_args = TrainingArguments(
    output_dir="./results_2",
    evaluation_strategy="no",
    learning_rate=1e-5,  # 낮은 학습률 설정
    per_device_train_batch_size=1,  # 작은 배치 크기 설정
    num_train_epochs=100,  # 높은 Epoch 수
    weight_decay=0.0,  # 가중치 감소를 최소화
    logging_strategy="steps",
    logging_steps=10,
    fp16=True,
    report_to="none"
)

# initailize trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_dataset
)

# train
trainer.train()
torch.cuda.empty_cache()

# save model and tokenizer
output_dir = "./trained_model"  
trainer.save_model(output_dir)
tokenizer.save_pretrained(output_dir) 